{{--<div id="preloader">--}}
{{--    <div class="spinner">--}}
{{--        --}}{{--            <img alt=" انتشارات دانشگاه صنتی شریف" class="logo mb-2" src="images/loader-img.gif" style="width: 130px"/><br>--}}
{{--        <div class="bounce1"></div>--}}
{{--        <div class="bounce2"></div>--}}
{{--        <div class="bounce3"></div>--}}
{{--    </div>--}}
{{--</div>--}}
<div id="custom-footer">
    <div class="position-relative container-fluid">
        <div class="row flex-wrap flex-row-reverse mt-5 footer-content">

            <div class="d-flex justify-content-center mt-5 pt-2 col-12">
                <p style="font-size: 21px;color: #1bb9d2;text-align: center">
                    .با ما در تماس باشید
                </p>
            </div>
            <div class="d-flex justify-content-center mt-2 col-12">
                <p style="font-size: 22px;color: #ffffff;text-align: center;line-height: 1.6">
                    خیابان آزادی، دانشگاه صنعتی شریف، مؤسسه انتشارات علمی  <i class="feather icon-map-pin"></i>
                </p>
            </div>

            <div class="d-flex justify-content-center mt-2 col-12">
                <p style="font-size: 18px;color: #ffffff;text-align: center;line-height: 1.6">
                    کارشناس انتشارات : ۳۴۴۰۲۷۷۸-۰۲۱  <i class="feather icon-phone"></i>
                </p>
            </div>
            <div class="d-flex justify-content-center mt-2 col-12">
                <p style="font-size: 18px;color: #ffffff;text-align: center;line-height: 1.6">
                    bookInfo@sharif.ir  <i class="feather icon-mail"></i>
                </p>
            </div>
        </div>
    </div>
    <div class="row py-1 pt-2" style="border-top:1px solid #1bb9d2">
        <div class="d-flex flex-row-reverse align-items-center  w-100 mr-5">
            <p style="font-size: 12px;color: #ffffff;text-align: center;line-height: 1.6">
                .تمامی حقوق مادی و معنوی این سامانه متعلق به انتشارات دانشگاه صنعتی شریف است
                <i class="feather icon-info"></i>
            </p>

        </div>

    </div>
</div>

